from fastapi import APIRouter, Depends, HTTPException, File, UploadFile, Form
from bson import ObjectId
from datetime import datetime
from typing import Optional

from app.core.database import database
from app.api.deps import require_roles, get_current_user
from app.models.material import new_material_doc, material_to_public
from app.schemas.material import CreateMaterialRequest, UpdateMaterialRequest
from app.utils.file_upload import save_upload_file, create_upload_dirs

router = APIRouter(prefix="/materials", tags=["materials"])


# ========== CREATE MATERIAL WITH FILE ==========
@router.post("/with-file")
async def create_material_with_file(
    moduleId: str = Form(...),
    title: str = Form(...),
    type: str = Form(...),
    content: str = Form(""),
    duration: int = Form(0),
    order: int = Form(0),
    isRequired: bool = Form(True),
    file: UploadFile = File(None),
    user: dict = Depends(require_roles("instructor", "admin")),
):
    """Create material with file upload"""
    db = database.db

    # Verify module exists
    module = await db.modules.find_one({"_id": ObjectId(moduleId)})
    if not module:
        raise HTTPException(status_code=404, detail="Module not found")

    course = await db.courses.find_one({"_id": ObjectId(module["courseId"])})
    if user["role"] == "instructor" and course["instructorId"] != str(user["_id"]):
        raise HTTPException(status_code=403, detail="You don't own this course")

    # Determine allowed extensions based on type
    allowed_types = {
        "video": [".mp4", ".avi", ".mov", ".mkv", ".webm"],
        "audio": [".mp3", ".wav", ".aac", ".ogg"],
        "pdf": [".pdf"],
        "image": [".jpg", ".jpeg", ".png", ".gif", ".webp"],
        "document": [".pdf", ".doc", ".docx", ".txt", ".rtf"],
        "presentation": [".ppt", ".pptx", ".key"],
        "link": [],  # No file for links
        "text": [],  # No file for text
    }

    # Save file if provided
    file_info = None
    if file and file.filename:
        file_info = await save_upload_file(
            file=file,
            subfolder="materials",
            prefix=f"material_{moduleId[:8]}",
            allowed_types=allowed_types.get(type, []),
        )

    doc = new_material_doc(
        module_id=moduleId,
        title=title,
        type=type,
        url=file_info["url"] if file_info else "",
        content=content,
        duration=duration,
        order=order,
        is_required=isRequired,
    )

    # Add file info if uploaded
    if file_info:
        doc["fileInfo"] = file_info

    result = await db.materials.insert_one(doc)
    doc["_id"] = result.inserted_id

    return {
        "success": True,
        "data": material_to_public(doc),
        "message": "Material created with file",
    }
