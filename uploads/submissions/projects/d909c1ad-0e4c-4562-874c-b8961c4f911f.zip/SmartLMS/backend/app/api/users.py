from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional, Literal
from pydantic import BaseModel, EmailStr, Field

from app.core.database import database
from app.core.security import get_password_hash
from app.api.deps import require_roles
from app.models.user import new_user_doc, user_to_public

router = APIRouter(prefix="/users", tags=["users"])

class CreateUserRequest(BaseModel):
    name: str = Field(min_length=2)
    email: EmailStr
    password: str = Field(min_length=6)
    role: Literal["instructor", "student"]

@router.get("")
async def list_users(
    role: Optional[str] = Query(None),
    user=Depends(require_roles("admin", "instructor")),
):
    db = database.db
    # Instructors may only list students (for enrollment)
    if user["role"] == "instructor":
        query = {"role": "student"}
    else:
        query = (
            {"role": role}
            if role in ("instructor", "student")
            else {"role": {"$in": ["instructor", "student"]}}
        )
    cursor = db.users.find(query).sort("createdAt", -1)
    users = [user_to_public(u) async for u in cursor]
    return {"success": True, "data": users, "message": "ok"}

@router.post("")
async def create_user(payload: CreateUserRequest, admin=Depends(require_roles("admin"))):
    db = database.db
    existing = await db.users.find_one({"email": payload.email.lower()})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    doc = new_user_doc(
        name=payload.name,
        email=payload.email,
        password_hash=get_password_hash(payload.password),
        role=payload.role,
    )
    result = await db.users.insert_one(doc)
    doc["_id"] = result.inserted_id
    return {"success": True, "data": user_to_public(doc), "message": "user created"}