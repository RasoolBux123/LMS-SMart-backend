#api/courses.py
from fastapi import APIRouter, Depends, HTTPException
from bson import ObjectId
from datetime import datetime
from app.core.database import database
from app.api.deps import require_roles, get_current_user
from app.models.course import new_course_doc, course_to_public
from app.schemas.course import CreateCourseRequest
from app.schemas.course import CreateCourseRequest, UpdateCourseRequest

router = APIRouter(prefix="/courses", tags=["courses"])


@router.get("")
async def list_courses(user: dict = Depends(get_current_user)):
    db = database.db
    if user["role"] == "instructor":
        query = {"instructorId": str(user["_id"])}
    elif user["role"] == "admin":
        query = {}
    else:
        enrollments = await db.enrollments.find({"userId": str(user["_id"])}).to_list(
            length=None
        )
        course_ids = [ObjectId(e["courseId"]) for e in enrollments]
        query = {"_id": {"$in": course_ids}}

    cursor = db.courses.find(query).sort("createdAt", -1)
    courses = [course_to_public(c) async for c in cursor]

    instructor_ids = {c["instructorId"] for c in courses if c["instructorId"]}
    valid_ids = [ObjectId(i) for i in instructor_ids if ObjectId.is_valid(i)]
    instructor_names = {}
    if valid_ids:
        async for u in db.users.find({"_id": {"$in": valid_ids}}):
            instructor_names[str(u["_id"])] = u.get("name", "")

    for c in courses:
        c["instructorName"] = instructor_names.get(c["instructorId"], "")

    return {"success": True, "data": courses, "message": "ok"}


@router.post("")
async def create_course(
    payload: CreateCourseRequest,
    user: dict = Depends(require_roles("instructor", "admin")),
):
    db = database.db

    # instructors can only ever own their own courses;
    # admins pick the instructor from the form (payload.instructorId)
    if user["role"] == "instructor":
        instructor_id = str(user["_id"])
    else:
        instructor_id = payload.instructorId or str(user["_id"])

    doc = new_course_doc(
        title=payload.title,
        description=payload.description,
        instructor_id=instructor_id,
        category=payload.category,
        level=payload.level,
        duration_weeks=payload.durationWeeks,
        thumbnail=payload.thumbnail,
        objectives=payload.objectives,
        prerequisites=payload.prerequisites,
        status=payload.status,
    )
    result = await db.courses.insert_one(doc)
    doc["_id"] = result.inserted_id

    course = course_to_public(doc)
    if instructor_id and ObjectId.is_valid(instructor_id):
        instructor = await db.users.find_one({"_id": ObjectId(instructor_id)})
        course["instructorName"] = instructor.get("name", "") if instructor else ""

    return {"success": True, "data": course, "message": "course created"}
@router.put("/{course_id}")
async def update_course(
    course_id: str,
    payload: UpdateCourseRequest,
    user: dict = Depends(require_roles("instructor", "admin")),
):
    db = database.db
    course = await db.courses.find_one({"_id": ObjectId(course_id)})
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")

    # instructors can only edit their own courses
    if user["role"] == "instructor" and course.get("instructorId") != str(user["_id"]):
        raise HTTPException(status_code=403, detail="Not allowed to edit this course")

    updates = payload.dict(exclude_unset=True)
    if "durationWeeks" in updates:
        pass  # already camelCase, no remapping needed
    if updates:
        updates["updatedAt"] = datetime.utcnow()
        await db.courses.update_one({"_id": ObjectId(course_id)}, {"$set": updates})

    updated = await db.courses.find_one({"_id": ObjectId(course_id)})
    result = course_to_public(updated)
    if result["instructorId"] and ObjectId.is_valid(result["instructorId"]):
        instructor = await db.users.find_one({"_id": ObjectId(result["instructorId"])})
        result["instructorName"] = instructor.get("name", "") if instructor else ""
    return {"success": True, "data": result, "message": "course updated"}


@router.delete("/{course_id}")
async def delete_course(
    course_id: str,
    user: dict = Depends(require_roles("instructor", "admin")),
):
    db = database.db
    course = await db.courses.find_one({"_id": ObjectId(course_id)})
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")

    if user["role"] == "instructor" and course.get("instructorId") != str(user["_id"]):
        raise HTTPException(status_code=403, detail="Not allowed to delete this course")

    await db.courses.delete_one({"_id": ObjectId(course_id)})
    return {"success": True, "data": None, "message": "course deleted"}