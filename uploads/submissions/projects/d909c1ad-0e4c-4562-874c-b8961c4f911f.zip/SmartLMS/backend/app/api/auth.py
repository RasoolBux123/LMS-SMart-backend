from fastapi import APIRouter, HTTPException, Depends, status
from datetime import datetime
from app.core.database import database
from app.core.security import verify_password, create_access_token, get_password_hash
from app.models.user import user_to_public
from app.schemas.user import LoginRequest
from app.api.deps import get_current_user

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/login")
async def login(payload: LoginRequest):
    db = database.db
    user = await db.users.find_one({"email": payload.email.lower()})
    if not user or not verify_password(payload.password, user["passwordHash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if user.get("status") != "active":
        raise HTTPException(status_code=403, detail="Account disabled")

    await db.users.update_one(
        {"_id": user["_id"]}, {"$set": {"lastLoginAt": datetime.utcnow()}}
    )
    token = create_access_token({"sub": str(user["_id"]), "role": user["role"]})
    return {
        "success": True,
        "data": {"user": user_to_public(user), "access_token": token},
        # "data": {"user": user_to_public(user), "token": token},
        "message": "logged in",
    }

@router.get("/me")
async def me(user: dict = Depends(get_current_user)):
    return {"success": True, "data": user_to_public(user), "message": "ok"}