from datetime import datetime


def new_material_doc(
    module_id: str,
    title: str,
    type: str,
    url: str = "",
    content: str = "",
    duration: int = 0,
    file_size: int = 0,
    order: int = 0,
    is_required: bool = True,
) -> dict:
    return {
        "moduleId": module_id,
        "title": title,
        "type": type,
        "url": url,
        "content": content,
        "duration": duration,
        "fileSize": file_size,
        "order": order,
        "isRequired": is_required,
        "viewCount": 0,
        "createdAt": datetime.utcnow(),
        "updatedAt": datetime.utcnow(),
    }


def material_to_public(doc: dict) -> dict:
    return {
        "id": str(doc["_id"]),
        "moduleId": doc["moduleId"],
        "title": doc["title"],
        "type": doc["type"],
        "url": doc.get("url", ""),
        "content": doc.get("content", ""),
        "duration": doc.get("duration", 0),
        "fileSize": doc.get("fileSize", 0),
        "order": doc.get("order", 0),
        "isRequired": doc.get("isRequired", True),
        "viewCount": doc.get("viewCount", 0),
        "createdAt": doc["createdAt"],
        "updatedAt": doc.get("updatedAt", doc["createdAt"]),
    }
