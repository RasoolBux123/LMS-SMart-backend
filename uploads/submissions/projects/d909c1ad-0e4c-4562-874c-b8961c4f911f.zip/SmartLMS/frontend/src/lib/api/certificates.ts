import { apiFetch, type ApiEnvelope } from "./client";

/**
 * Certificates are not implemented on the backend yet — there is no
 * /certificates router. These helpers describe the intended contract so the
 * pages have something typed to call once it lands; until then each request
 * will surface a 404 through ApiError rather than failing silently.
 */

export type CertificateStatus = "issued" | "pending" | "revoked";

export interface Certificate {
  id: string;
  studentId: string;
  studentName?: string;
  programId?: string;
  programTitle?: string;
  courseId?: string;
  courseTitle?: string;
  status: CertificateStatus;
  issuedAt: string | null;
  /** Public verification code printed on the certificate. */
  serial?: string;
  url?: string;
}

export interface ListCertificatesParams {
  studentId?: string;
  programId?: string;
  status?: CertificateStatus | "all";
}

export async function listCertificates(params: ListCertificatesParams = {}) {
  const qs = new URLSearchParams();
  if (params.studentId) qs.set("studentId", params.studentId);
  if (params.programId) qs.set("programId", params.programId);
  if (params.status && params.status !== "all") qs.set("status", params.status);

  const suffix = qs.toString() ? `?${qs.toString()}` : "";
  return apiFetch<ApiEnvelope<Certificate[]>>(`/certificates${suffix}`);
}

export async function getCertificate(id: string) {
  return apiFetch<ApiEnvelope<Certificate>>(`/certificates/${id}`);
}

export async function issueCertificate(data: {
  studentId: string;
  programId?: string;
  courseId?: string;
}) {
  return apiFetch<ApiEnvelope<Certificate>>("/certificates", {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export async function revokeCertificate(id: string) {
  return apiFetch<ApiEnvelope<Certificate>>(`/certificates/${id}/revoke`, {
    method: "PATCH",
  });
}
