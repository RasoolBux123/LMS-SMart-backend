"use client";

import { Suspense, useCallback, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { toast } from "sonner";
import { Inbox, Loader2 } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/shared/empty-state";
import {
  SubmissionsTable,
  type SubmissionRow,
} from "@/features/instructor/submissions-table";
import { useAuth } from "@/hooks/useAuth";
import {
  assignmentsApi,
  quizzesApi,
  examsApi,
  projectsApi,
  type CourseworkKind,
  type CourseworkListItem,
} from "@/lib/api/coursework";
import { listCourseEnrollments } from "@/lib/api/enrollments";
import { gradeSubmission } from "@/lib/api/assignments";
import type { Submission, SubmissionStatus, User } from "@/types";
import { errorMessage } from "@/lib/utils";

type CourseworkItem = CourseworkListItem & {
  kind: CourseworkKind;
};

function asArray<T>(raw: unknown): T[] {
  if (Array.isArray(raw)) return raw as T[];
  if (raw && typeof raw === "object") {
    const d = (raw as { data?: unknown }).data;
    if (Array.isArray(d)) return d as T[];
  }
  return [];
}

const KIND_LABEL: Record<CourseworkKind, string> = {
  assignments: "Assignment",
  quizzes: "Quiz",
  exams: "Exam",
  projects: "Project",
};

const KIND_API = {
  assignments: assignmentsApi,
  quizzes: quizzesApi,
  exams: examsApi,
  projects: projectsApi,
} as const;

function SubmissionsPageInner() {
  const { user } = useAuth();
  const searchParams = useSearchParams();
  const router = useRouter();

  const [items, setItems] = useState<CourseworkItem[]>([]);
  const [selectedId, setSelectedId] = useState(
    () => searchParams.get("item") ?? searchParams.get("assignment") ?? "",
  );
  const [rows, setRows] = useState<SubmissionRow[]>([]);
  const [loadingList, setLoadingList] = useState(true);
  const [loadingRows, setLoadingRows] = useState(false);
  const [listError, setListError] = useState<string | null>(null);

  // Load ALL coursework kinds in parallel
  useEffect(() => {
    let cancelled = false;
    setLoadingList(true);
    setListError(null);

    Promise.all([
      assignmentsApi.list({}).catch(() => []),
      quizzesApi.list({}).catch(() => []),
      examsApi.list({}).catch(() => []),
      projectsApi.list({}).catch(() => []),
    ])
      .then(([assignments, quizzes, exams, projects]) => {
        if (cancelled) return;

        const combined: CourseworkItem[] = [
          ...asArray<CourseworkListItem>(assignments).map((a) => ({
            ...a,
            kind: "assignments" as const,
          })),
          ...asArray<CourseworkListItem>(quizzes).map((q) => ({
            ...q,
            kind: "quizzes" as const,
          })),
          ...asArray<CourseworkListItem>(exams).map((e) => ({
            ...e,
            kind: "exams" as const,
          })),
          ...asArray<CourseworkListItem>(projects).map((p) => ({
            ...p,
            kind: "projects" as const,
          })),
        ];

        // Newest first
        combined.sort(
          (a, b) =>
            new Date(b.createdAt || 0).getTime() -
            new Date(a.createdAt || 0).getTime(),
        );

        setItems(combined);

        setSelectedId((prev) => {
          if (prev && combined.some((i) => i.id === prev)) return prev;
          return combined[0]?.id ?? "";
        });
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setItems([]);
        setListError(errorMessage(err, "Could not load coursework."));
        toast.error(errorMessage(err, "Could not load coursework."));
      })
      .finally(() => {
        if (!cancelled) setLoadingList(false);
      });

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const selected =
    items.find((i) => i.id === selectedId) ?? items[0] ?? null;

  const loadRows = useCallback(async (item: CourseworkItem) => {
    setLoadingRows(true);
    try {
      const api = KIND_API[item.kind];

      const [subsRes, enrollRes] = await Promise.all([
        api.listSubmissions(item.id).catch(() => ({ data: [] })),
        item.courseId
          ? listCourseEnrollments(item.courseId).catch(() => ({ data: [] }))
          : Promise.resolve({ data: [] }),
      ]);

      const subsList = asArray<{
        id: string;
        assignmentId?: string;
        studentId: string;
        status?: string;
        submittedAt?: string | null;
        files?: {
          id?: string;
          name?: string;
          url?: string;
          kind?: string;
          size?: number;
        }[];
        attemptNumber?: number;
        marksAwarded?: number | null;
        score?: number | null;
        feedback?: string | null;
        passFail?: "pass" | "fail" | null;
      }>(subsRes);

      const enrollList = asArray<{
        userId?: string;
        student?: {
          id: string;
          name: string;
          email: string;
          rollNumber?: string;
        } | null;
      }>(enrollRes);

      const byStudent = new Map<string, (typeof subsList)[0]>();
      for (const s of subsList) {
        if (!s?.studentId) continue;
        const existing = byStudent.get(s.studentId);
        if (
          !existing ||
          (s.attemptNumber ?? 1) > (existing.attemptNumber ?? 1)
        ) {
          byStudent.set(s.studentId, s);
        }
      }

      const studentMap = new Map<
        string,
        { id: string; name: string; email: string; rollNumber?: string }
      >();

      for (const e of enrollList) {
        if (e.student?.id) {
          studentMap.set(e.student.id, {
            id: e.student.id,
            name: e.student.name || e.student.email || e.student.id,
            email: e.student.email || "",
            rollNumber: e.student.rollNumber,
          });
        } else if (e.userId) {
          studentMap.set(e.userId, {
            id: e.userId,
            name: e.userId,
            email: "",
          });
        }
      }

      for (const [sid] of byStudent) {
        if (!studentMap.has(sid)) {
          studentMap.set(sid, { id: sid, name: sid, email: "" });
        }
      }

      const built: SubmissionRow[] = [];
      for (const [, st] of studentMap) {
        const raw = byStudent.get(st.id);
        const student: User = {
          id: st.id,
          name: st.name,
          email: st.email,
          role: "student",
          avatarColor: "#0D9488",
          rollNumber: st.rollNumber,
        };

        if (!raw) {
          built.push({ student, submission: null, status: "pending" });
          continue;
        }

        const marks =
          raw.marksAwarded != null
            ? raw.marksAwarded
            : raw.score != null
              ? raw.score
              : null;

        let status: SubmissionStatus = "submitted";
        if (marks != null || raw.status === "graded") status = "graded";
        else if (raw.status === "late") status = "late";

        const submission: Submission = {
          id: raw.id,
          assignmentId: raw.assignmentId || item.id,
          studentId: raw.studentId,
          status,
          submittedAt: raw.submittedAt ?? null,
          files: (raw.files || []).map((f, i) => ({
            id: f.id || String(i),
            name: f.name || "file",
            kind:
              (f.kind as "pdf" | "docx" | "image" | "zip" | "other") || "other",
            size: f.size || 0,
            url: f.url || "",
          })),
          attemptNumber: raw.attemptNumber ?? 1,
          marksAwarded: marks,
          feedback: raw.feedback ?? null,
          passFail: raw.passFail ?? null,
        };

        built.push({ student, submission, status });
      }

      built.sort((x, y) => x.student.name.localeCompare(y.student.name));
      setRows(built);
    } catch (err: unknown) {
      setRows([]);
      toast.error(errorMessage(err, "Could not load submissions."));
    } finally {
      setLoadingRows(false);
    }
  }, []);

  useEffect(() => {
    if (!selected) {
      setRows([]);
      return;
    }
    loadRows(selected);
  }, [selected, loadRows]);

  function handleChange(id: string) {
    setSelectedId(id);
    router.replace(`/instructor/submissions?item=${id}`, { scroll: false });
  }

  async function handleGradeSave(
    studentId: string,
    marks: number,
    feedback: string,
    passFail: "pass" | "fail",
  ) {
    const row = rows.find((r) => r.student.id === studentId);
    if (!row?.submission?.id) {
      toast.error("No submission to grade.");
      throw new Error("No submission");
    }
    await gradeSubmission(row.submission.id, marks, feedback, passFail);
    setRows((prev) =>
      prev.map((r) =>
        r.student.id === studentId && r.submission
          ? {
              ...r,
              submission: {
                ...r.submission,
                marksAwarded: marks,
                feedback,
                passFail,
                status: "graded",
              },
              status: "graded",
            }
          : r,
      ),
    );
  }

  if (loadingList) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center gap-2 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
        Loading coursework…
      </div>
    );
  }

  if (listError || items.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-2xl font-semibold">Submissions</h1>
          <p className="text-sm text-muted-foreground">
            Review, grade, and give feedback on student work.
          </p>
        </div>
        <EmptyState
          icon={Inbox}
          title={listError ? "Could not load coursework" : "No coursework yet"}
          description={
            listError ||
            "Create and publish an assignment, quiz, exam or project first. Student submissions will show up here."
          }
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Submissions</h1>
          <p className="text-sm text-muted-foreground">
            Review, grade, and give feedback on student work.
          </p>
        </div>

        <Select
          value={selected?.id ?? selectedId}
          onValueChange={handleChange}
        >
          <SelectTrigger className="w-full sm:w-96">
            <SelectValue placeholder="Choose assignment / quiz / exam / project" />
          </SelectTrigger>
          <SelectContent>
            {items.map((item) => (
              <SelectItem key={item.id} value={item.id}>
                <span className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">
                    [{KIND_LABEL[item.kind]}]
                  </span>
                  {item.title}
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selected && (
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div>
              <div className="flex items-center gap-2">
                <CardTitle>{selected.title}</CardTitle>
                <Badge variant="secondary" className="text-xs">
                  {KIND_LABEL[selected.kind]}
                </Badge>
              </div>
              <p className="mt-0.5 text-sm text-muted-foreground">
                {selected.course?.title || selected.course?.code || "—"} ·{" "}
                {selected.totalMarks ?? 100} points
              </p>
            </div>
            <Badge variant="outline">
              {selected.submittedCount ??
                rows.filter((r) => r.submission).length}
              /{selected.enrolled ?? rows.length} submitted
            </Badge>
          </CardHeader>
          <CardContent>
            {loadingRows ? (
              <div className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading submissions…
              </div>
            ) : rows.length === 0 ? (
              <EmptyState
                icon={Inbox}
                title="No submissions yet"
                description="When enrolled students submit work for this item, they will appear here."
              />
            ) : (
              <SubmissionsTable
                key={selected.id}
                rows={rows}
                totalMarks={selected.totalMarks ?? 100}
                onGradeSave={handleGradeSave}
              />
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default function InstructorSubmissionsPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-[40vh] items-center justify-center text-muted-foreground">
          Loading…
        </div>
      }
    >
      <SubmissionsPageInner />
    </Suspense>
  );
}




// "use client";

// import { Suspense, useCallback, useEffect, useState } from "react";
// import { useSearchParams, useRouter } from "next/navigation";
// import { toast } from "sonner";
// import { Inbox, Loader2 } from "lucide-react";
// import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
// import {
//   Select,
//   SelectTrigger,
//   SelectValue,
//   SelectContent,
//   SelectItem,
// } from "@/components/ui/select";
// import { Badge } from "@/components/ui/badge";
// import { EmptyState } from "@/components/shared/empty-state";
// import {
//   SubmissionsTable,
//   type SubmissionRow,
// } from "@/features/instructor/submissions-table";
// import { useAuth } from "@/hooks/useAuth";
// import {
//   getAssignments,
//   listSubmissions,
//   gradeSubmission,
// } from "@/lib/api/assignments";
// import { listCourseEnrollments } from "@/lib/api/enrollments";
// import type { AssignmentListItem } from "@/types/assignment";
// import type { Submission, SubmissionStatus, User } from "@/types";
// import { errorMessage } from "@/lib/utils";

// function asArray<T>(raw: unknown): T[] {
//   if (Array.isArray(raw)) return raw as T[];
//   if (raw && typeof raw === "object") {
//     const d = (raw as { data?: unknown }).data;
//     if (Array.isArray(d)) return d as T[];
//   }
//   return [];
// }

// function SubmissionsPageInner() {
//   const { user } = useAuth();
//   const searchParams = useSearchParams();
//   const router = useRouter();

//   const [assignments, setAssignments] = useState<AssignmentListItem[]>([]);
//   const [assignmentId, setAssignmentId] = useState(
//     () => searchParams.get("assignment") ?? "",
//   );
//   const [rows, setRows] = useState<SubmissionRow[]>([]);
//   const [loadingList, setLoadingList] = useState(true);
//   const [loadingRows, setLoadingRows] = useState(false);
//   const [listError, setListError] = useState<string | null>(null);

//   useEffect(() => {
//     let cancelled = false;
//     setLoadingList(true);
//     setListError(null);

//     getAssignments({})
//       .then((raw) => {
//         if (cancelled) return;
//         const list = asArray<AssignmentListItem>(raw);
//         setAssignments(list);
//         setAssignmentId((prev) => {
//           if (prev && list.some((a) => a.id === prev)) return prev;
//           return list[0]?.id ?? "";
//         });
//       })
//       .catch((err: unknown) => {
//         if (cancelled) return;
//         setAssignments([]);
//         setListError(errorMessage(err, "Could not load assignments."));
//         toast.error(errorMessage(err, "Could not load assignments."));
//       })
//       .finally(() => {
//         if (!cancelled) setLoadingList(false);
//       });

//     return () => {
//       cancelled = true;
//     };
//   }, [user?.id]);

//   const assignment =
//     assignments.find((a) => a.id === assignmentId) ?? assignments[0] ?? null;

//   const loadRows = useCallback(async (a: AssignmentListItem) => {
//     setLoadingRows(true);
//     try {
//       const [subsRes, enrollRes] = await Promise.all([
//         listSubmissions(a.id).catch(() => ({ data: [] })),
//         a.courseId
//           ? listCourseEnrollments(a.courseId).catch(() => ({ data: [] }))
//           : Promise.resolve({ data: [] }),
//       ]);

//       const subsList = asArray<{
//         id: string;
//         assignmentId?: string;
//         studentId: string;
//         status?: string;
//         submittedAt?: string | null;
//         files?: { id?: string; name?: string; url?: string; kind?: string; size?: number }[];
//         attemptNumber?: number;
//         marksAwarded?: number | null;
//         score?: number | null;
//         feedback?: string | null;
//         passFail?: "pass" | "fail" | null;
//       }>(subsRes);

//       const enrollList = asArray<{
//         userId?: string;
//         student?: { id: string; name: string; email: string; rollNumber?: string } | null;
//       }>(enrollRes);

//       const byStudent = new Map<string, (typeof subsList)[0]>();
//       for (const s of subsList) {
//         if (!s?.studentId) continue;
//         const existing = byStudent.get(s.studentId);
//         if (!existing || (s.attemptNumber ?? 1) > (existing.attemptNumber ?? 1)) {
//           byStudent.set(s.studentId, s);
//         }
//       }

//       const studentMap = new Map<
//         string,
//         { id: string; name: string; email: string; rollNumber?: string }
//       >();

//       for (const e of enrollList) {
//         if (e.student?.id) {
//           studentMap.set(e.student.id, {
//             id: e.student.id,
//             name: e.student.name || e.student.email || e.student.id,
//             email: e.student.email || "",
//             rollNumber: e.student.rollNumber,
//           });
//         } else if (e.userId) {
//           studentMap.set(e.userId, { id: e.userId, name: e.userId, email: "" });
//         }
//       }

//       for (const [sid] of byStudent) {
//         if (!studentMap.has(sid)) {
//           studentMap.set(sid, { id: sid, name: sid, email: "" });
//         }
//       }

//       const built: SubmissionRow[] = [];
//       for (const [, st] of studentMap) {
//         const raw = byStudent.get(st.id);
//         const student: User = {
//           id: st.id,
//           name: st.name,
//           email: st.email,
//           role: "student",
//           avatarColor: "#0D9488",
//           rollNumber: st.rollNumber,
//         };

//         if (!raw) {
//           built.push({ student, submission: null, status: "pending" });
//           continue;
//         }

//         const marks =
//           raw.marksAwarded != null
//             ? raw.marksAwarded
//             : raw.score != null
//               ? raw.score
//               : null;

//         let status: SubmissionStatus = "submitted";
//         if (marks != null || raw.status === "graded") status = "graded";
//         else if (raw.status === "late") status = "late";

//         const submission: Submission = {
//           id: raw.id,
//           assignmentId: raw.assignmentId || a.id,
//           studentId: raw.studentId,
//           status,
//           submittedAt: raw.submittedAt ?? null,
//           files: (raw.files || []).map((f, i) => ({
//             id: f.id || String(i),
//             name: f.name || "file",
//             kind: (f.kind as "pdf" | "docx" | "image" | "zip" | "other") || "other",
//             size: f.size || 0,
//             url: f.url || "",
//           })),
//           attemptNumber: raw.attemptNumber ?? 1,
//           marksAwarded: marks,
//           feedback: raw.feedback ?? null,
//           passFail: raw.passFail ?? null,
//         };

//         built.push({ student, submission, status });
//       }

//       built.sort((x, y) => x.student.name.localeCompare(y.student.name));
//       setRows(built);
//     } catch (err: unknown) {
//       setRows([]);
//       toast.error(errorMessage(err, "Could not load submissions."));
//     } finally {
//       setLoadingRows(false);
//     }
//   }, []);

//   useEffect(() => {
//     if (!assignment) {
//       setRows([]);
//       return;
//     }
//     loadRows(assignment);
//   }, [assignment, loadRows]);

//   function handleChange(id: string) {
//     setAssignmentId(id);
//     router.replace(`/instructor/submissions?assignment=${id}`, { scroll: false });
//   }

//   async function handleGradeSave(
//     studentId: string,
//     marks: number,
//     feedback: string,
//     passFail: "pass" | "fail",
//   ) {
//     const row = rows.find((r) => r.student.id === studentId);
//     if (!row?.submission?.id) {
//       toast.error("No submission to grade.");
//       throw new Error("No submission");
//     }
//     await gradeSubmission(row.submission.id, marks, feedback, passFail);
//     setRows((prev) =>
//       prev.map((r) =>
//         r.student.id === studentId && r.submission
//           ? {
//             ...r,
//             submission: {
//               ...r.submission,
//               marksAwarded: marks,
//               feedback,
//               passFail,
//               status: "graded",
//             },
//             status: "graded",
//           }
//           : r,
//       ),
//     );
//   }

//   // async function handleGradeSave(
//   //   studentId: string,
//   //   marks: number,
//   //   feedback: string,
//   //   passFail: "pass" | "fail",
//   // ) {
//   //   const row = rows.find((r) => r.student.id === studentId);
//   //   if (!row?.submission?.id) {
//   //     toast.error("No submission to grade.");
//   //     return;
//   //   }
//   //   await gradeSubmission(row.submission.id, marks, feedback);
//   //   setRows((prev) =>
//   //     prev.map((r) =>
//   //       r.student.id === studentId && r.submission
//   //         ? {
//   //           ...r,
//   //           submission: {
//   //             ...r.submission,
//   //             marksAwarded: marks,
//   //             feedback,
//   //             passFail,
//   //             status: "graded",
//   //           },
//   //           status: "graded",
//   //         }
//   //         : r,
//   //     ),
//   //   );
//   // }

//   if (loadingList) {
//     return (
//       <div className="flex min-h-[40vh] items-center justify-center gap-2 text-muted-foreground">
//         <Loader2 className="h-5 w-5 animate-spin" />
//         Loading assignments…
//       </div>
//     );
//   }

//   if (listError || assignments.length === 0) {
//     return (
//       <div className="space-y-6">
//         <div>
//           <h1 className="font-display text-2xl font-semibold">Submissions</h1>
//           <p className="text-sm text-muted-foreground">
//             Review, grade, and give feedback on student work.
//           </p>
//         </div>
//         <EmptyState
//           icon={Inbox}
//           title={listError ? "Could not load assignments" : "No assignments yet"}
//           description={
//             listError ||
//             "Create and publish an assignment first. Student submissions will show up here."
//           }
//         />
//       </div>
//     );
//   }

//   return (
//     <div className="space-y-6">
//       <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
//         <div>
//           <h1 className="font-display text-2xl font-semibold">Submissions</h1>
//           <p className="text-sm text-muted-foreground">
//             Review, grade, and give feedback on student work.
//           </p>
//         </div>
//         <Select value={assignment?.id ?? assignmentId} onValueChange={handleChange}>
//           <SelectTrigger className="w-full sm:w-80">
//             <SelectValue placeholder="Choose an assignment" />
//           </SelectTrigger>
//           <SelectContent>
//             {assignments.map((a) => (
//               <SelectItem key={a.id} value={a.id}>
//                 {a.title}
//               </SelectItem>
//             ))}
//           </SelectContent>
//         </Select>
//       </div>

//       {assignment && (
//         <Card>
//           <CardHeader className="flex-row items-center justify-between space-y-0">
//             <div>
//               <CardTitle>{assignment.title}</CardTitle>
//               <p className="mt-0.5 text-sm text-muted-foreground">
//                 {assignment.course?.title || assignment.course?.code || "—"} ·{" "}
//                 {assignment.totalMarks ?? 100} points
//               </p>
//             </div>
//             <Badge variant="outline">
//               {assignment.submittedCount ??
//                 rows.filter((r) => r.submission).length}
//               /{assignment.enrolled ?? rows.length} submitted
//             </Badge>
//           </CardHeader>
//           <CardContent>
//             {loadingRows ? (
//               <div className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground">
//                 <Loader2 className="h-4 w-4 animate-spin" />
//                 Loading submissions…
//               </div>
//             ) : rows.length === 0 ? (
//               <EmptyState
//                 icon={Inbox}
//                 title="No submissions yet"
//                 description="When enrolled students submit work for this assignment, they will appear here."
//               />
//             ) : (
//               <SubmissionsTable
//                 key={assignment.id}
//                 rows={rows}
//                 totalMarks={assignment.totalMarks ?? 100}
//                 onGradeSave={handleGradeSave}
//               />
//             )}
//           </CardContent>
//         </Card>
//       )}
//     </div>
//   );
// }

// export default function InstructorSubmissionsPage() {
//   return (
//     <Suspense
//       fallback={
//         <div className="flex min-h-[40vh] items-center justify-center text-muted-foreground">
//           Loading…
//         </div>
//       }
//     >
//       <SubmissionsPageInner />
//     </Suspense>
//   );
// }














