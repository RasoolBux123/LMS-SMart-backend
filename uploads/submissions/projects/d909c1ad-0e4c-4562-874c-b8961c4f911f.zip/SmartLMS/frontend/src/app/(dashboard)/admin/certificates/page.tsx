"use client";

import ComingSoon from "@/app/components/ui/ComingSoon";

export default function AdminCertificatesPage() {
    return (
        <ComingSoon
            title="Certificates"
            description="Certificates for students who successfully complete their courses will be issued and verified here.
            "
        />
    );
}