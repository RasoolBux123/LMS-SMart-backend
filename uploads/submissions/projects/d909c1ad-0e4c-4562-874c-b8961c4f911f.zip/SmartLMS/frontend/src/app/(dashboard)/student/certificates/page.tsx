"use client";

import ComingSoon from "@/app/components/ui/ComingSoon";

export default function StudentCertificatesPage() {
    return (
        <ComingSoon
            title="Certificates"
            description="Course complete karne par aapke certificates yahan available honge."
        />
    );
}