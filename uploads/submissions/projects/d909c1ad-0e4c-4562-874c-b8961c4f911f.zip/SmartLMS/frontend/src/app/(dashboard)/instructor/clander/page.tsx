"use client";

import { useState } from "react";

import {
    Calendar,
    dateFnsLocalizer,
    View,
} from "react-big-calendar";

import {
    format,
    parse,
    startOfWeek,
    getDay,
} from "date-fns";

import { enUS } from "date-fns/locale";

import "react-big-calendar/lib/css/react-big-calendar.css";


const locales = {
    "en-US": enUS,
};


const localizer = dateFnsLocalizer({
    format,
    parse,
    startOfWeek,
    getDay,
    locales,
});


// Instructor Calendar Events
const events = [

    {
        title: "AI Class",
        start: new Date(2026, 7, 12, 9, 0),
        end: new Date(2026, 7, 12, 11, 0),
        type: "class",
    },


    {
        title: "Project Review",
        start: new Date(2026, 7, 18, 10, 0),
        end: new Date(2026, 7, 18, 12, 0),
        type: "review",
    },


    {
        title: "Grade Submission",
        start: new Date(2026, 7, 25),
        end: new Date(2026, 7, 25),
        allDay: true,
        type: "grade",
    },

];


// Event Colors
const eventStyleGetter = (event: any) => {

    let background = "#4338ca";


    if (event.type === "class") {
        background = "#0d9488";
    }


    if (event.type === "review") {
        background = "#f59e0b";
    }


    if (event.type === "grade") {
        background = "#2563eb";
    }


    return {

        style: {

            backgroundColor: background,

            color: "white",

            borderRadius: "8px",

            border: "none",

            padding: "5px 8px",

            fontSize: "13px",

            fontWeight: "600",

        },

    };

};



export default function CalendarPage() {


    const [currentDate, setCurrentDate] =
        useState(new Date());


    const [currentView, setCurrentView] =
        useState<View>("month");



    return (

        <div className="p-6">


            <h1 className="mb-5 text-2xl font-bold">
                Instructor Calendar
            </h1>



            <div
                className="
          rounded-xl
          bg-card
          p-5
          shadow
        "
            >


                <Calendar


                    localizer={localizer}


                    events={events}


                    startAccessor="start"


                    endAccessor="end"



                    date={currentDate}


                    onNavigate={(date) => {

                        setCurrentDate(date);

                    }}



                    view={currentView}


                    onView={(view) => {

                        setCurrentView(view);

                    }}



                    views={[
                        "month",
                        "week",
                        "day",
                    ]}



                    defaultView="month"



                    toolbar={true}



                    popup={true}



                    eventPropGetter={
                        eventStyleGetter
                    }



                    style={{
                        height: 650,
                    }}


                />


            </div>


        </div>

    );

}