"use client";

import { useState } from "react";

import {
    Calendar,
    dateFnsLocalizer,
    View,
} from "react-big-calendar";

import {
    format,
    parse,
    startOfWeek,
    getDay,
} from "date-fns";

import { enUS } from "date-fns/locale";

import "react-big-calendar/lib/css/react-big-calendar.css";


const locales = {
    "en-US": enUS,
};


const localizer = dateFnsLocalizer({
    format,
    parse,
    startOfWeek,
    getDay,
    locales,
});


// Student Calendar Events
const events = [

    {
        title: "AI Class",
        start: new Date(2026, 7, 15, 10, 0),
        end: new Date(2026, 7, 15, 11, 0),
        type: "quiz",
    },


    {
        title: "Grade Submission",
        start: new Date(2026, 7, 20, 9, 0),
        end: new Date(2026, 7, 20, 12, 0),
        type: "exam",
    },


    {
        title: "Project Submission",
        start: new Date(2026, 7, 25),
        end: new Date(2026, 7, 25),
        allDay: true,
        type: "project",
    },

];



// Event Colors
const eventStyleGetter = (event: any) => {

    let background = "#4338ca";


    if (event.type === "quiz") {
        background = "#16a34a";
    }


    if (event.type === "exam") {
        background = "#dc2626";
    }


    if (event.type === "project") {
        background = "#2563eb";
    }


    return {
        style: {
            backgroundColor: background,
            color: "white",
            borderRadius: "8px",
            border: "none",
            padding: "4px 8px",
            fontSize: "13px",
            fontWeight: "600",
        },
    };
};



export default function StudentCalendar() {


    const [date, setDate] = useState(
        new Date()
    );


    const [view, setView] =
        useState<View>("month");



    return (

        <div className="p-6">


            <h1 className="mb-5 text-2xl font-bold">
                Student Calendar
            </h1>



            <div className="
        rounded-xl
        bg-#4338ca
        p-5
        shadow
      ">


                <Calendar

                    localizer={localizer}


                    events={events}


                    startAccessor="start"


                    endAccessor="end"


                    date={date}


                    view={view}


                    onNavigate={(newDate) => {

                        setDate(newDate);

                    }}


                    onView={(newView) => {

                        setView(newView);

                    }}



                    views={[
                        "month",
                        "week",
                        "day",
                    ]}



                    defaultView="month"



                    toolbar={true}



                    popup={true}



                    eventPropGetter={
                        eventStyleGetter
                    }



                    style={{
                        height: 650,
                    }}


                />


            </div>


        </div>

    );

}
