"use client";

/**
 * Instructor courses page — shows courses assigned to the signed-in
 * instructor, with expandable colorful modules + ability to add new modules.
 */

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  BookOpen,
  ChevronRight,
  Search,
  Users,
  Loader2,
  Plus,
} from "lucide-react";
import {
  listCourses,
  listModules,
  createModule,
  type Course,
  type Module,
} from "@/lib/api/courses";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/shared/empty-state";
import { useAuth } from "@/hooks/useAuth";
import { errorMessage, cn } from "@/lib/utils";

const STATUS_VARIANT: Record<string, "success" | "warning" | "secondary"> = {
  active: "success",
  published: "success",
  draft: "warning",
  archived: "secondary",
};

const MODULE_COLORS = [
  { bg: "bg-violet-100", text: "text-violet-700", border: "border-violet-200", icon: "bg-violet-600" },
  { bg: "bg-emerald-100", text: "text-emerald-700", border: "border-emerald-200", icon: "bg-emerald-600" },
  { bg: "bg-sky-100", text: "text-sky-700", border: "border-sky-200", icon: "bg-sky-600" },
  { bg: "bg-rose-100", text: "text-rose-700", border: "border-rose-200", icon: "bg-rose-600" },
  { bg: "bg-amber-100", text: "text-amber-700", border: "border-amber-200", icon: "bg-amber-600" },
  { bg: "bg-indigo-100", text: "text-indigo-700", border: "border-indigo-200", icon: "bg-indigo-600" },
  { bg: "bg-teal-100", text: "text-teal-700", border: "border-teal-200", icon: "bg-teal-600" },
  { bg: "bg-fuchsia-100", text: "text-fuchsia-700", border: "border-fuchsia-200", icon: "bg-fuchsia-600" },
];

export default function InstructorCoursesPage() {
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [modulesByCourse, setModulesByCourse] = useState<
    Record<string, Module[]>
  >({});
  const [loadingModules, setLoadingModules] = useState<string | null>(null);

  // Add Module form state
  const [addingFor, setAddingFor] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;

    listCourses(user?.id ? { instructorId: user.id } : {})
      .then((res) => {
        if (!cancelled) setCourses(res.data);
      })
      .catch((err) => {
        if (!cancelled)
          toast.error(errorMessage(err, "Could not load your courses."));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return courses;

    return courses.filter((course) =>
      `${course.title} ${course.description}`.toLowerCase().includes(term),
    );
  }, [courses, search]);

  async function toggleCourse(courseId: string) {
    if (expanded === courseId) {
      setExpanded(null);
      setAddingFor(null);
      return;
    }

    setExpanded(courseId);
    setAddingFor(null);

    if (!modulesByCourse[courseId]) {
      setLoadingModules(courseId);
      try {
        const res = await listModules(courseId);
        setModulesByCourse((prev) => ({ ...prev, [courseId]: res.data }));
      } catch {
        setModulesByCourse((prev) => ({ ...prev, [courseId]: [] }));
      } finally {
        setLoadingModules(null);
      }
    }
  }

  async function handleAddModule(courseId: string) {
    const title = newTitle.trim();
    if (!title) {
      toast.error("Module title is required.");
      return;
    }

    setSaving(true);
    try {
      const currentModules = modulesByCourse[courseId] || [];
      const orderIndex = currentModules.length;

      const res = await createModule(courseId, title, orderIndex);
      const created = res.data;

      setModulesByCourse((prev) => ({
        ...prev,
        [courseId]: [...(prev[courseId] || []), created],
      }));

      setNewTitle("");
      setAddingFor(null);
      toast.success("Module added successfully.");
    } catch (err) {
      toast.error(errorMessage(err, "Could not add module."));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-2xl font-semibold text-foreground">
          My courses
        </h1>
        <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
          Courses assigned to you. Expand a course to review its modules.
        </p>
      </header>

      <div className="relative sm:max-w-sm">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint-foreground"
          aria-hidden
        />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search your courses…"
          aria-label="Search courses"
          className="pl-9"
        />
      </div>

      {loading ? (
        <div className="flex items-center justify-center gap-2.5 py-20 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          Loading courses…
        </div>
      ) : visible.length === 0 ? (
        <EmptyState
          icon={BookOpen}
          title={search ? "No courses match your search" : "No courses assigned"}
          description={
            search
              ? "Try a different search term."
              : "Once an administrator assigns you a course, it will appear here."
          }
        />
      ) : (
        <div className="space-y-3">
          {visible.map((course) => {
            const isOpen = expanded === course.id;
            const modules = modulesByCourse[course.id];
            const isAdding = addingFor === course.id;

            return (
              <Card key={course.id} className="overflow-hidden">
                <button
                  type="button"
                  onClick={() => toggleCourse(course.id)}
                  aria-expanded={isOpen}
                  className="flex w-full items-start gap-3 p-4 text-left transition-colors hover:bg-secondary/50 sm:p-5"
                >
                  <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary-soft">
                    <BookOpen className="h-5 w-5 text-on-primary-soft" />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-display text-base font-semibold text-foreground">
                        {course.title}
                      </h2>
                      <Badge
                        variant={STATUS_VARIANT[course.status] ?? "secondary"}
                      >
                        {course.status}
                      </Badge>
                    </div>

                    {course.description && (
                      <p className="clamp-2 mt-1 text-sm leading-relaxed text-muted-foreground">
                        {course.description}
                      </p>
                    )}

                    <p className="mt-2 flex items-center gap-1.5 text-xs text-faint-foreground">
                      <Users className="h-3.5 w-3.5 shrink-0" aria-hidden />
                      {course.studentCount ?? 0} enrolled
                    </p>
                  </div>

                  <ChevronRight
                    className={cn(
                      "mt-2 h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                      isOpen && "rotate-90",
                    )}
                    aria-hidden
                  />
                </button>

                {isOpen && (
                  <CardContent className="border-t border-border p-4 pt-4 sm:p-5 sm:pt-4">
                    {loadingModules === course.id ? (
                      <p className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        Loading modules…
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {/* Modules list - colorful cards */}
                        {!modules || modules.length === 0 ? (
                          <p className="text-sm text-muted-foreground">
                            No modules have been added to this course yet.
                          </p>
                        ) : (
                          <ul className="grid gap-2.5 sm:grid-cols-2">
                            {modules
                              .slice()
                              .sort((a, b) => a.orderIndex - b.orderIndex)
                              .map((module, index) => {
                                const color =
                                  MODULE_COLORS[index % MODULE_COLORS.length];

                                return (
                                  <li
                                    key={module.id}
                                    className={cn(
                                      "flex items-center gap-3 rounded-xl border px-3.5 py-3 transition-colors",
                                      color.bg,
                                      color.border,
                                    )}
                                  >
                                    <div
                                      className={cn(
                                        "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-xs font-bold text-white",
                                        color.icon,
                                      )}
                                    >
                                      {String(index + 1).padStart(2, "0")}
                                    </div>
                                    <div className="min-w-0 flex-1">
                                      <p
                                        className={cn(
                                          "truncate text-sm font-medium",
                                          color.text,
                                        )}
                                      >
                                        {module.title}
                                      </p>
                                      <p className="text-xs text-muted-foreground">
                                        Module {index + 1}
                                      </p>
                                    </div>
                                  </li>
                                );
                              })}
                          </ul>
                        )}

                        {/* Add Module form / button */}
                        {isAdding ? (
                          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                            <Input
                              value={newTitle}
                              onChange={(e) => setNewTitle(e.target.value)}
                              placeholder="Module title (e.g. Introduction to MongoDB)"
                              className="flex-1"
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === "Enter")
                                  handleAddModule(course.id);
                                if (e.key === "Escape") {
                                  setAddingFor(null);
                                  setNewTitle("");
                                }
                              }}
                            />
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleAddModule(course.id)}
                                disabled={saving}
                              >
                                {saving ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  "Save"
                                )}
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setAddingFor(null);
                                  setNewTitle("");
                                }}
                                disabled={saving}
                              >
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            className="gap-1.5"
                            onClick={() => setAddingFor(course.id)}
                          >
                            <Plus className="h-4 w-4" />
                            Add Module
                          </Button>
                        )}
                      </div>
                    )}
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}


// "use client";

// /**
//  * Instructor courses page — shows courses assigned to the signed-in
//  * instructor, with expandable modules + ability to add new modules.
//  */

// import { useEffect, useMemo, useState } from "react";
// import { toast } from "sonner";
// import {
//   BookOpen,
//   ChevronRight,
//   Search,
//   Users,
//   Loader2,
//   FileText,
//   Plus,
// } from "lucide-react";
// import {
//   listCourses,
//   listModules,
//   createModule,
//   type Course,
//   type Module,
// } from "@/lib/api/courses";
// import { Card, CardContent } from "@/components/ui/card";
// import { Badge } from "@/components/ui/badge";
// import { Input } from "@/components/ui/input";
// import { Button } from "@/components/ui/button";
// import { EmptyState } from "@/components/shared/empty-state";
// import { useAuth } from "@/hooks/useAuth";
// import { errorMessage, cn } from "@/lib/utils";

// const STATUS_VARIANT: Record<string, "success" | "warning" | "secondary"> = {
//   active: "success",
//   published: "success",
//   draft: "warning",
//   archived: "secondary",
// };

// export default function InstructorCoursesPage() {
//   const { user } = useAuth();
//   const [courses, setCourses] = useState<Course[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [search, setSearch] = useState("");
//   const [expanded, setExpanded] = useState<string | null>(null);
//   const [modulesByCourse, setModulesByCourse] = useState<
//     Record<string, Module[]>
//   >({});
//   const [loadingModules, setLoadingModules] = useState<string | null>(null);

//   // Add Module form state
//   const [addingFor, setAddingFor] = useState<string | null>(null);
//   const [newTitle, setNewTitle] = useState("");
//   const [saving, setSaving] = useState(false);

//   useEffect(() => {
//     let cancelled = false;

//     listCourses(user?.id ? { instructorId: user.id } : {})
//       .then((res) => {
//         if (!cancelled) setCourses(res.data);
//       })
//       .catch((err) => {
//         if (!cancelled)
//           toast.error(errorMessage(err, "Could not load your courses."));
//       })
//       .finally(() => {
//         if (!cancelled) setLoading(false);
//       });

//     return () => {
//       cancelled = true;
//     };
//   }, [user?.id]);

//   const visible = useMemo(() => {
//     const term = search.trim().toLowerCase();
//     if (!term) return courses;

//     return courses.filter((course) =>
//       `${course.title} ${course.description}`.toLowerCase().includes(term),
//     );
//   }, [courses, search]);

//   async function toggleCourse(courseId: string) {
//     if (expanded === courseId) {
//       setExpanded(null);
//       setAddingFor(null);
//       return;
//     }

//     setExpanded(courseId);
//     setAddingFor(null);

//     if (!modulesByCourse[courseId]) {
//       setLoadingModules(courseId);
//       try {
//         const res = await listModules(courseId);
//         setModulesByCourse((prev) => ({ ...prev, [courseId]: res.data }));
//       } catch {
//         setModulesByCourse((prev) => ({ ...prev, [courseId]: [] }));
//       } finally {
//         setLoadingModules(null);
//       }
//     }
//   }

//   async function handleAddModule(courseId: string) {
//     const title = newTitle.trim();
//     if (!title) {
//       toast.error("Module title is required.");
//       return;
//     }

//     setSaving(true);
//     try {
//       const currentModules = modulesByCourse[courseId] || [];
//       const orderIndex = currentModules.length;

//       const res = await createModule(courseId, title, orderIndex);
//       const created = res.data;

//       setModulesByCourse((prev) => ({
//         ...prev,
//         [courseId]: [...(prev[courseId] || []), created],
//       }));

//       setNewTitle("");
//       setAddingFor(null);
//       toast.success("Module added successfully.");
//     } catch (err) {
//       toast.error(errorMessage(err, "Could not add module."));
//     } finally {
//       setSaving(false);
//     }
//   }

//   return (
//     <div className="space-y-6">
//       <header>
//         <h1 className="font-display text-2xl font-semibold text-foreground">
//           My courses
//         </h1>
//         <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
//           Courses assigned to you. Expand a course to review its modules.
//         </p>
//       </header>

//       <div className="relative sm:max-w-sm">
//         <Search
//           className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint-foreground"
//           aria-hidden
//         />
//         <Input
//           value={search}
//           onChange={(e) => setSearch(e.target.value)}
//           placeholder="Search your courses…"
//           aria-label="Search courses"
//           className="pl-9"
//         />
//       </div>

//       {loading ? (
//         <div className="flex items-center justify-center gap-2.5 py-20 text-sm text-muted-foreground">
//           <Loader2 className="h-4 w-4 animate-spin" />
//           Loading courses…
//         </div>
//       ) : visible.length === 0 ? (
//         <EmptyState
//           icon={BookOpen}
//           title={search ? "No courses match your search" : "No courses assigned"}
//           description={
//             search
//               ? "Try a different search term."
//               : "Once an administrator assigns you a course, it will appear here."
//           }
//         />
//       ) : (
//         <div className="space-y-3">
//           {visible.map((course) => {
//             const isOpen = expanded === course.id;
//             const modules = modulesByCourse[course.id];
//             const isAdding = addingFor === course.id;

//             return (
//               <Card key={course.id} className="overflow-hidden">
//                 <button
//                   type="button"
//                   onClick={() => toggleCourse(course.id)}
//                   aria-expanded={isOpen}
//                   className="flex w-full items-start gap-3 p-4 text-left transition-colors hover:bg-secondary/50 sm:p-5"
//                 >
//                   <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary-soft">
//                     <BookOpen className="h-5 w-5 text-on-primary-soft" />
//                   </div>

//                   <div className="min-w-0 flex-1">
//                     <div className="flex flex-wrap items-center gap-2">
//                       <h2 className="font-display text-base font-semibold text-foreground">
//                         {course.title}
//                       </h2>
//                       <Badge
//                         variant={STATUS_VARIANT[course.status] ?? "secondary"}
//                       >
//                         {course.status}
//                       </Badge>
//                     </div>

//                     {course.description && (
//                       <p className="clamp-2 mt-1 text-sm leading-relaxed text-muted-foreground">
//                         {course.description}
//                       </p>
//                     )}

//                     <p className="mt-2 flex items-center gap-1.5 text-xs text-faint-foreground">
//                       <Users className="h-3.5 w-3.5 shrink-0" aria-hidden />
//                       {course.studentCount ?? 0} enrolled
//                     </p>
//                   </div>

//                   <ChevronRight
//                     className={cn(
//                       "mt-2 h-4 w-4 shrink-0 text-muted-foreground transition-transform",
//                       isOpen && "rotate-90",
//                     )}
//                     aria-hidden
//                   />
//                 </button>

//                 {isOpen && (
//                   <CardContent className="border-t border-border p-4 pt-4 sm:p-5 sm:pt-4">
//                     {loadingModules === course.id ? (
//                       <p className="flex items-center gap-2 text-sm text-muted-foreground">
//                         <Loader2 className="h-3.5 w-3.5 animate-spin" />
//                         Loading modules…
//                       </p>
//                     ) : (
//                       <div className="space-y-3">
//                         {/* Modules list */}
//                         {!modules || modules.length === 0 ? (
//                           <p className="text-sm text-muted-foreground">
//                             No modules have been added to this course yet.
//                           </p>
//                         ) : (
//                           <ul className="space-y-1.5">
//                             {modules
//                               .slice()
//                               .sort((a, b) => a.orderIndex - b.orderIndex)
//                               .map((module) => (
//                                 <li
//                                   key={module.id}
//                                   className="flex items-center gap-2.5 rounded-lg bg-secondary px-3 py-2.5 text-sm text-foreground"
//                                 >
//                                   <FileText
//                                     className="h-3.5 w-3.5 shrink-0 text-muted-foreground"
//                                     aria-hidden
//                                   />
//                                   <span className="truncate">{module.title}</span>
//                                 </li>
//                               ))}
//                           </ul>
//                         )}

//                         {/* Add Module form / button */}
//                         {isAdding ? (
//                           <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
//                             <Input
//                               value={newTitle}
//                               onChange={(e) => setNewTitle(e.target.value)}
//                               placeholder="Module title (e.g. Introduction to MongoDB)"
//                               className="flex-1"
//                               autoFocus
//                               onKeyDown={(e) => {
//                                 if (e.key === "Enter") handleAddModule(course.id);
//                                 if (e.key === "Escape") {
//                                   setAddingFor(null);
//                                   setNewTitle("");
//                                 }
//                               }}
//                             />
//                             <div className="flex gap-2">
//                               <Button
//                                 size="sm"
//                                 onClick={() => handleAddModule(course.id)}
//                                 disabled={saving}
//                               >
//                                 {saving ? (
//                                   <Loader2 className="h-4 w-4 animate-spin" />
//                                 ) : (
//                                   "Save"
//                                 )}
//                               </Button>
//                               <Button
//                                 size="sm"
//                                 variant="outline"
//                                 onClick={() => {
//                                   setAddingFor(null);
//                                   setNewTitle("");
//                                 }}
//                                 disabled={saving}
//                               >
//                                 Cancel
//                               </Button>
//                             </div>
//                           </div>
//                         ) : (
//                           <Button
//                             size="sm"
//                             variant="outline"
//                             className="gap-1.5"
//                             onClick={() => setAddingFor(course.id)}
//                           >
//                             <Plus className="h-4 w-4" />
//                             Add Module
//                           </Button>
//                         )}
//                       </div>
//                     )}
//                   </CardContent>
//                 )}
//               </Card>
//             );
//           })}
//         </div>
//       )}
//     </div>
//   );
// }


