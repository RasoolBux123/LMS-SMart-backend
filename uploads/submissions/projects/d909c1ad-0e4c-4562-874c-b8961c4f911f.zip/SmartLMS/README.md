# SmartLMS — Backend (FastAPI) + Frontend (Next.js)

## What was fixed

1. **Instructor → Student connection (main bug)**  
   When an instructor creates / publishes an **assignment, quiz, exam or project**, enrolled students now see it on their portal (list pages + dashboard).  
   Previously the student UI read empty seed arrays (`@/data/*`) and the backend response shapes did not match the frontend contract.

2. **Unified coursework API** (`backend/app/api/coursework.py`)  
   One factory powers `/assignments`, `/quizzes`, `/exams`, `/projects` with the shape the Next.js client expects:
   - list returns a **raw array** of list-items (course joined + counts)
   - `status`: draft | published | archived  
   - students only receive **published** items from **enrolled** courses  
   - instructors only see their own items (filter by `instructorId`)

3. **Auth login envelope**  
   Frontend now correctly unwraps `{ success, data: { user, access_token } }` and stores the token.

4. **Student dashboard**  
   Uses live API via `useStudentCoursework` instead of mock selectors.

5. **CORS**  
   Allows `http://localhost:3000` and configured `FRONTEND_URL`.

6. **JWT settings**  
   Respects `ALGORITHM` / `ACCESS_TOKEN_EXPIRE_MINUTES` from `.env`.

## How to run

### Backend
```bash
cd backend
python3 -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Frontend `.env.local` already has:
```
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### Seed admin (optional)
```bash
cd backend
source .venv/bin/activate
python seed_admin.py
# admin@smartlms.com / ChangeMe123
```

### Demo data (optional)
```bash
python seed_demo.py
```

## Flow that now works

1. Instructor logs in → creates course (or uses existing).  
2. Admin/instructor enrolls students in that course.  
3. Instructor creates Assignment / Quiz / Exam / Project and sets status to **published**.  
4. Student logs in → opens Assignments / Quizzes / Exams / Projects → sees the published items for enrolled courses.  
5. Student dashboard shows the same live data.

## API docs

With backend running: http://localhost:8000/docs
